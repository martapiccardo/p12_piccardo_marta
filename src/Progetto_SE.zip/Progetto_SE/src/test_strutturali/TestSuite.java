package test_strutturali;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	AbbonamentoTest.class,
	AereoTest.class,
	CompagniaAereaTest.class,
	GestoreCompagniaAereaTest.class,
	VoloTest.class,
	SistemaTest.class
})
public class TestSuite {

}
